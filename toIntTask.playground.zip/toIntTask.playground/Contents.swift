import UIKit
import Foundation


/*
 TASK1:
 cast an array of Any to array of ints
 example:
 input: [1, 2, 3, [4, 5, 6], 7, 8, 9, [[10], 11], 12]
 output: [1, 2, 3, 4, 5, 6, 7, 8, 9, 10, 11, 12]
 */

let input: [Any] = [1, 2, 3, [4, 5, 6], 7, 8, 9, [[10], 11], 12]

func toInt(_ input: [Any]) -> [Int] {
    
}
print("\(toInt(input))")
